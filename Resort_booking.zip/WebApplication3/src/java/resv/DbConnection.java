package resv;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class DbConnection {
    public static Connection getConnectToReservation() throws SQLException,ClassNotFoundException
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con =null;
        String url="jdbc:mysql://localhost:3306/";
        String dbName="reservation";
        String UserName="root";
        String password="root543";
        con=DriverManager.getConnection(url+dbName,UserName,password);
        return con;
    }
    
}